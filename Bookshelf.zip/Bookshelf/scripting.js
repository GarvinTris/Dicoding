 document.addEventListener("DOMContentLoaded", function(){

    const item = document.getElementById("incompleteBookshelfList");
    const completeList = document.getElementById("completeBookshelfList");

    const dataform = document.getElementById("inputBook");
    const submit = document.getElementById("bookSubmit");

    const SAVE_EVENT = 'save-Bookshelf';
    const STORAGE_KEY = 'APP-Bookshelf';

    submit.addEventListener("click",()=>{
        item.innerHTML = '';
    })
    dataform.addEventListener("submit", (e) =>{
        
        // e + 1 jika ditekan
        item.innerHTML = ''; //clear nilai berlanjut
        completeList.innerHTML = ''; //clear nilai berlanjut

        adding(); /* pemasuk bila e ditekan maka buat satu article
        dan akan terus tambah 1 menjadi 2, jadi ke create 2 article
        dan seterusnya. */
        
        e.preventDefault(); // mencegah
    });
    
    const user = [];
    const START = 'STARTING';
    document.addEventListener(START, function() {
        item.innerHTML = '';
        completeList.innerHTML = '';
    
        for (const userItem of user) {
            const group = create(userItem);
            if (userItem.is) {
                completeList.appendChild(group);
                console.log("checked");
            } else {
                item.appendChild(group);
                console.log("unchecked");
            }
        }
    });

document.addEventListener(SAVE_EVENT, function () {
    console.log(localStorage.getItem(STORAGE_KEY));
  });

  function checkStorage() {
    if (typeof Storage === 'undefined') {
        alert("Browser anda tidak mendukung");
        return false;
    }
    return true;
}


    function deleting(red, articles) {
        red.addEventListener("click", () => 
        {
            articles.remove();
            user.pop()
        });
    }

    function adding(){

    const title = document.getElementById("inputBookTitle").value;
    const author = document.getElementById("inputBookAuthor").value;
    const Year = document.getElementById("inputBookYear").value;

    const check = document.getElementById("inputBookIsComplete").checked;

        const id = idgenerate();
        const obj = data(id,title,author,Year,check);
        user.push(obj);

        document.dispatchEvent(new Event(START));
        saving()
    }

    function saving(){
    if(checkStorage()){
        const convert = JSON.stringify(user);
        localStorage.setItem(STORAGE_KEY, convert);
        console.log("Data saved to localStorage:", convert);
        document.dispatchEvent(new Event(START));
    }
}


    function idgenerate(){
        return +new Date();
    }

   function data(id,title,author,year,is){
        return {
        id,
        title,
        author,
        year,
        is
        }
    } 

    function create(data){

        const article = document.createElement("article");
        article.classList.add("book_item");
        item.append(article)

        const h3 = document.createElement("h2");
        h3.innerText = data.title;
        article.append(h3);

        const p = document.createElement("p");
        p.innerText = "Penulis: " + data.author;
        article.append(p);

        const pp = document.createElement("p");
        pp.innerText = "Tahun: " + data.year;
        article.append(pp);
       
        const div = document.createElement("div");
        div.classList.add("action");
        item.append(div);

        const btn_green = document.createElement("button");
        btn_green.textContent = "Selesai Dibaca";
        btn_green.classList.add("green");
        div.append(btn_green); //tombol ganti ke selesai baca

        const btn_red = document.createElement("button");
        btn_red.textContent = "Hapus Buku";
        btn_red.classList.add("red");
        div.append(btn_red); //tombol hapus

        article.append(div);

        change(btn_green,article,data.is);
        deleting(btn_red,article); //const articles = buat article

        return article;
        }
    function change(green,articles,is){
        green.addEventListener("click",()=>{
            if(!is){
                completeList.append(articles);
                green.textContent = "Belum Selesai Baca";
                is = true;
            }
            else {
                item.append(articles);
                green.textContent = "Selesai Dibaca";
                is = false;
            }
        });
    }

    //red itu button hapus
    //articles = buat article dalam item
    
});